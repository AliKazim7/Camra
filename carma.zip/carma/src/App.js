import logo from "./logo.svg";
import "./App.css";
import HomePage from "./pages/home";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import LandingPage from "./pages/landing/landing";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/"  exact element={<HomePage />} />
        <Route path="/create"  element={<LandingPage />} />
      </Routes>
    </div>
  );
}

export default App;
