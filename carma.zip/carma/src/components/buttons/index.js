import { AppProvider, Button } from "@shopify/polaris";
import React from "react";
import "./button.css";

function ButtonExample(props) {
  const { onChange } = props;
  return (
    <div className="button_container">
      <div className="button_style" onClick={() => onChange()}>
        <span className="text_color">Install</span>
      </div>
    </div>
  );
}

export default ButtonExample;
