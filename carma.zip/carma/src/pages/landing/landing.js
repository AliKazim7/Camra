import React, { useState } from "react";
import Header from "../header/header";
import Switch from "react-switch";
import { QuantityPicker } from "react-qty-picker";
import "./landing.css";

const LandingPage = () => {
  const [chargeUKTree, setChargeUKTree] = useState(false);
  const [chargeOffshoreTree, setChargeOffshoreTree] = useState(false);
  const [customerPay, setCustomerPay] = useState(false);
  const [merchantPay, setMerchantPay] = useState(false);
  const [cancelCarma, setCancelCarma] = useState(false);
  const [plant1Tree, setPlant1Tree] = useState(false);
  const [plantNTree, setPlantNTree] = useState(false);
  const [plantTreeEvery, setPlantTreeEvery] = useState(false);

  return (
    <div>
      <Header />
      <div className="main_container">
        <div className="form_inputs">
          <span className="block_text">Location of trees</span>
          <div style={{ display: "flex", alignItems: "center" }}>
            <span style={{ marginRight: "20px" }}>
              <span className="block_text">UK</span>
              £5 per tree
            </span>
            <Switch
              checked={chargeUKTree}
              onChange={() => setChargeUKTree(!chargeUKTree)}
            />
          </div>
          <div style={{ display: "flex", alignItems: "center" }}>
            <span style={{ marginRight: "20px" }}>
              <span className="block_text">Offshore</span>
              £5 per tree
            </span>
            <Switch
              checked={chargeOffshoreTree}
              onChange={() => setChargeOffshoreTree(!chargeOffshoreTree)}
            />
          </div>
        </div>
        <div className="form_inputs">
          <span className="block_text">Who is paying</span>
          <div style={{ width: "63%" }}>
            <div style={{ display: "flex" }}>
              <div style={{ display: "flex" }}>
                <span className="block_text">Customer</span>
                <div style={{ marginLeft: "20px" }}>
                  <Switch
                    checked={customerPay}
                    onChange={() => setCustomerPay(!customerPay)}
                  />
                </div>
              </div>
              <div style={{ marginLeft: "20%" }}>
                <span>
                  Allow customers to opt in and pay a little extra and we
                  collect that exact amount from you at the end of your billing
                  cycle
                </span>
              </div>
            </div>
            <div style={{ display: "flex", marginTop: "20px" }}>
              <div style={{ display: "flex" }}>
                <span className="block_text">Merchant</span>
                <div style={{ marginLeft: "20px" }}>
                  <Switch
                    checked={merchantPay}
                    onChange={() => setMerchantPay(!merchantPay)}
                  />
                </div>
              </div>
              <div style={{ marginLeft: "20%" }}>
                <span>
                  Make your orders carbon neutral by paying on behalf of your
                  customers
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="form_inputs">
          <div
            style={{
              display: "grid",
            }}
          >
            <span className="block_text">Capped number of trees per month</span>
            <span>Adjust the maximum number of trees per month</span>
          </div>
          <div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
              }}
            >
              Capped number of trees per month
              <div style={{ marginLeft: "40px" }}>
                <QuantityPicker />
              </div>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "20px",
              }}
            >
              <span>= £125 / Month</span>
              <span>=150 tonnes of CO2e</span>
            </div>
          </div>
        </div>
        <div className="form_inputs">
          <div
            style={{
              display: "grid",
              height: "70px",
            }}
          >
            <span className="block_text">How do you want to plant trees</span>
            <span>Select how you want to plant a tree at point of sales</span>
          </div>
          <div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                margin: "10px 0px",
              }}
            >
              <Switch
                checked={plantTreeEvery}
                onChange={() => setPlantTreeEvery(!plantTreeEvery)}
              />
              <div style={{ display: "grid", marginLeft: "20%" }}>
                <span>For every product bought</span>
                <span>Plant this number of trees per product sold</span>
                <QuantityPicker />
              </div>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                margin: "10px 0px",
              }}
            >
              <Switch
                checked={plantNTree}
                onChange={() => setPlantNTree(!plantNTree)}
              />
              <div style={{ display: "grid", marginLeft: "20%" }}>
                <span>Plant number of trees per order</span>
                <span>Plant X tree every time 1 order is made</span>
                <QuantityPicker />
              </div>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                margin: "10px 0px",
              }}
            >
              <Switch
                checked={plant1Tree}
                onChange={() => setPlant1Tree(!plant1Tree)}
              />
              <div style={{ display: "grid", marginLeft: "20%" }}>
                <span>
                  Plant 1 tree every time this revenue is exceeded as an order
                </span>
                <span>For every X pounds spent on a single order</span>
                <QuantityPicker />
              </div>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <Switch
                checked={cancelCarma}
                onChange={() => setCancelCarma(!cancelCarma)}
              />
              <div style={{ display: "grid" }}>
                <span>
                  Never | Use this option to disables Carma and billing
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="form_inputs">
          <div
            style={{
              display: "grid",
            }}
          >
            <span className="block_text">
              Add a progress widget to your store
            </span>
          </div>
          <div>See Documentation</div>
        </div>
        <div className="form_inputs">
          <div
            style={{
              display: "grid",
            }}
          >
            <span className="block_text">
              Do you want to earn commission based on high volume
            </span>
          </div>
          <div>See Documentation</div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
