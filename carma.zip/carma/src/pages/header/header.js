import { Image } from "@shopify/polaris";
import React from "react";
import './header.css'

const Header = () => {
  return (
    <header className="header">
      {" "}
      <Image
        source={require("../../assests/logo.png")}
        style={{ width: "20px", height: "20px" }}
      />{" "}
      Carma, for better tomorrow
    </header>
  );
};

export default Header;
