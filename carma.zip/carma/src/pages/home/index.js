import { Heading, Image } from "@shopify/polaris";
import React from "react";
import { useNavigate } from "react-router-dom";
import ButtonExample from "../../components/buttons";
import Header from "../header/header";
import "./home.css";

const HomePage = () => {
  const navigation = useNavigate();

  const handleNavigation = () => {
    console.log("handleNAvigation")
    navigation('/create')
  }

  return (
    <div>
      <Header />

      <div className="main_container_home">
        <div>
          <div className="para_header">
            Install Carma, for better tomorrow
          </div>
          <p className="main_paragraph">
            With every transaction you can plant trees and provide employment to
            Veterans in the UK or impoverished communities across the globe.
          </p>
          <ButtonExample onChange={() => handleNavigation()} />
        </div>
        <div>
          <Image source={require("../../assests/cover.png")} />
        </div>
      </div>
    </div>
  );
};

export default HomePage;
